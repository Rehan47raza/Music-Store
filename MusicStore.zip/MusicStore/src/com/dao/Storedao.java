package com.dao;
import java.sql.*;  
import java.util.ArrayList;  
import java.util.List;  
import com.bean.Store;  
public class Storedao {  
  
public static Connection getConnection(){  
    Connection con=null;  
    try{  
    	System.out.println(oracle.jdbc.driver.OracleDriver.BUILD_DATE);
        System.out.println(Class.class.desiredAssertionStatus());
        Class.forName("oracle.jdbc.driver.OracleDriver");  
        con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");  
    }catch(Exception e){System.out.println(e);}  
    return con;  
}  
public static int save(Store u){  
    int status=0;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("insert into register2(id,name,password,email,sex,country,language, music_type,genre, price ,discount,track,awards,others,image,sample) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        ps.setInt(1,u.getId()); 
        ps.setString(2,u.getName());  
        ps.setString(3,u.getPassword());  
        ps.setString(4,u.getEmail());  
        ps.setString(5,u.getSex());  
        ps.setString(6,u.getCountry()); 
        ps.setString(7,u.getLanguage());
        ps.setString(8,u.getMusic_type());
        ps.setString(9,u.getGenre());
        ps.setInt(10, u.getPrice());
        ps.setInt(11, u.getDiscount());
        ps.setString(12,u.getTrack());
        ps.setString(13,u.getAwards());
        ps.setString(14,u.getOthers());
        ps.setString(15,u.getImage());
        ps.setString(16,u.getSample());
        status=ps.executeUpdate();  
    }catch(Exception e){System.out.println(e);}  
    return status;  
}  
public static int update(Store u){  
    int status=0;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement(  
"update register2 set name=?,password=?,email=?,sex=?,country=?,language=?,music_type=?,genre=?,price=?,discount=?,track=?,awards=?,others=?,image=?,sample=? where id=?");  
        ps.setString(1,u.getName());  
        ps.setString(2,u.getPassword());  
        ps.setString(3,u.getEmail());  
        ps.setString(4,u.getSex());  
        ps.setString(5,u.getCountry());
        ps.setString(6,u.getLanguage());
        ps.setString(7,u.getMusic_type());
        ps.setString(8,u.getGenre());
        ps.setInt(9,u.getPrice());
        ps.setInt(10, u.getDiscount());
        ps.setString(11,u.getTrack());
        ps.setString(12,u.getAwards());
        ps.setString(13,u.getOthers());
        ps.setString(14,u.getImage());
        ps.setString(15,u.getSample());
        ps.setInt(16,u.getId());  
        status=ps.executeUpdate(); 
        System.out.println(status);
    }catch(Exception e){System.out.println(e);}  
    return status;  
}  
public static int delete(Store u){  
    int status=0;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("delete from register2 where id=?");  
        ps.setInt(1,u.getId());  
        status=ps.executeUpdate();  
    }catch(Exception e){System.out.println(e);}  
  
    return status;  
}  
public static List<Store> getAllRecords(){  
    List<Store> list=new ArrayList<Store>();  
      
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("select * from register2");  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            Store u=new Store();  
            u.setId(rs.getInt("id"));  
            u.setName(rs.getString("name"));  
            u.setPassword(rs.getString("password"));  
            u.setEmail(rs.getString("email"));  
            u.setSex(rs.getString("sex"));  
            u.setCountry(rs.getString("country"));  
            u.setLanguage(rs.getString("language"));
            u.setMusic_type(rs.getString("music_type"));
            u.setGenre(rs.getString("genre"));
            u.setPrice(rs.getInt("price"));
            u.setDiscount(rs.getInt("discount"));
            u.setTrack(rs.getString("track"));
            u.setAwards(rs.getString("awards"));
            u.setOthers(rs.getString("others"));
            u.setImage(rs.getString("image"));
            u.setSample(rs.getString("sample"));

            list.add(u);  
        }  
    }catch(Exception e){System.out.println(e);}  
    return list;  
}  
public static Store getRecordById(int id){  
    Store u=null;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("select * from register2 where id=?");  
        ps.setInt(1,id);  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            u=new Store();  
            u.setId(rs.getInt("id"));  
            u.setName(rs.getString("name"));  
            u.setPassword(rs.getString("password"));  
            u.setEmail(rs.getString("email"));  
            u.setSex(rs.getString("sex"));  
            u.setCountry(rs.getString("country"));  
            u.setLanguage(rs.getString("language"));
            u.setMusic_type(rs.getString("music_type"));
            u.setGenre(rs.getString("genre"));
            u.setPrice(rs.getInt("price"));
            u.setDiscount(rs.getInt("discount"));
            u.setTrack(rs.getString("track"));
            u.setAwards(rs.getString("awards"));
            u.setOthers(rs.getString("others"));
            u.setImage(rs.getString("image"));
            u.setSample(rs.getString("sample"));
        }  
    }catch(Exception e){System.out.println(e);}  
    return u;  
}  
}  
