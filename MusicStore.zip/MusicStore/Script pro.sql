
CREATE TABLE MyTunes(
Song_id NUMBER(5) PRIMARY Key, 
Title VARCHAR2(25),
Artiste VARCHAR2(25),
Music_Director VARCHAR2(25),
Language VARCHAR2(10)  CHECK(Language IN ('Hindi','English')),
Music_Type VARCHAR2(10)  CHECK (Music_Type IN ('Audio','Video')),
Genre VARCHAR2(25),
Availibility VARCHAR2(25) CHECK(Availibility IN ('Online','In Stock')),
Format VARCHAR2(25)  CHECK(Format IN ('Tape','CD','DVD')),
Online_Price NUMBER(5,2),
Discount NUMBER(5),
Cover_Image BLOB,
Track_Listing VARCHAR2(25),
Other_Specifications VARCHAR2(25),
Awards_if_any VARCHAR2(25),
Sample_Contents_Upload BLOB
);


SELECT * FROM MyTunes;

insert into MyTunes1 values(101,'q','w','e','Hindi','Audio','y','Online','Tape',190,10,'a','s','d','f','g');
insert into MyTunes1 values(102,'q','w','e','Hindi','Audio','y','Online','Tape',190,10,'a','s','d','f','g');

insert into MyTunes1(Song_id,Title,Artiste,Music_Director,Language,Music_Type,Genre,Availibility,Format,Online_Price,Discount,Cover_Image,Track_Listing,Other_Specifications,Awards_if_any,Sample_Contents_Upload) values(103,'q','w','e','Hindi','Audio','y','Online','Tape',190,10,'a','s','d','f','g');