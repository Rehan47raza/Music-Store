package com.dao;
import java.sql.*;  
import java.util.ArrayList;  
import java.util.List;  
import com.bean.Store;  
public class Storedao {  
  
public static Connection getConnection(){  
    Connection con=null;  
    try{  
        Class.forName("oracle.jdbc.driver.OracleDriver");  
        con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");  
    }catch(Exception e){System.out.println(e);}  
    return con;  
}  
public static int save(Store u){  
    int status=0;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("insert into  MyTunes1(Song_id,Title,Artiste,Music_Director,Language,Music_Type,Genre,Availibility,Format,Online_Price,Discount,Cover_Image,Track_Listing,Other_Specifications,Awards_if_any,Sample_Contents_Upload) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        ps.setInt(1,u.getSongId()); 
        ps.setString(2,u.getTitle());  
        ps.setString(3,u.getArtist());  
        ps.setString(4,u.getDirector());  
        ps.setString(5,u.getLang());  
        ps.setString(6,u.getType()); 
        ps.setString(7,u.getGenre()); 
        ps.setString(8,u.getAvail());  
        ps.setString(9,u.getFormat());  
        ps.setDouble(10,u.getPrice());  
        ps.setInt(11,u.getDiscount());  
        ps.setString(12,u.getImg());
        ps.setString(13,u.getTracks());  
        ps.setString(14,u.getOther());  
        ps.setString(15,u.getAwards());  
        ps.setString(16,u.getDoc());
        status=ps.executeUpdate();  
        System.out.println(status);
        System.out.println(u.getSongId());
    }catch(Exception e){System.out.println(e);}  
    return status;  
}  
public static int update(Store u){  
    int status=0;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement(  
"update MyTunes1 set Title=?,Artiste=?,Music_Director=?,Language=?,Music_Type=?,Genre=?,Availibility=?,Format=?,Online_Price=?,Discount=?,Cover_Image=?,Track_Listing=?,Other_Specifications=?,Awards_if_any=?,Sample_Contents_Upload=? where Song_id=?");  
       
        ps.setString(1,u.getTitle());  
        ps.setString(2,u.getArtist());  
        ps.setString(3,u.getDirector());  
        ps.setString(4,u.getLang());  
        ps.setString(5,u.getType()); 
        ps.setString(6,u.getGenre()); 
        ps.setString(7,u.getAvail());  
        ps.setString(8,u.getFormat());  
        ps.setDouble(9,u.getPrice());  
        ps.setInt(10,u.getDiscount());  
        ps.setString(11,u.getImg());
        ps.setString(12,u.getTracks());  
        ps.setString(13,u.getOther());  
        ps.setString(14,u.getAwards());  
        ps.setString(15,u.getDoc());
        ps.setInt(16,u.getSongId()); 
        status=ps.executeUpdate();  
    }catch(Exception e){System.out.println(e);}  
    return status;  
}

public static int delete(Store u){  
    int status=0;  
    try{  
        Connection con=getConnection();
        String sql="delete from MyTunes1 where Song_id=?";
        PreparedStatement ps=con.prepareStatement(sql); 
        
		ps.setInt(1,u.getSongId());  
        status=ps.executeUpdate(); 
        System.out.println(status);
    }catch(Exception e){System.out.println(e);}  
  
    return status;  
} 

public static List<Store> getAllRecords(){  
    List<Store> list=new ArrayList<Store>();  
      
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("select * from MyTunes1");  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            Store u=new Store();  
            u.setSongId(rs.getInt("Song_id")); 
            u.setTitle(rs.getString("Title"));
            u.setArtist(rs.getString("Artiste"));
            u.setDirector(rs.getString("Music_Director"));
            u.setLang(rs.getString("Language"));
            u.setType(rs.getString("Music_Type"));
            u.setGenre(rs.getString("Genre"));
            u.setAvail(rs.getString("Availibility"));
            u.setFormat(rs.getString("Format"));
            u.setPrice(rs.getDouble("Online_Price"));
            u.setDiscount(rs.getInt("Discount"));
            u.setImg(rs.getString("Cover_Image"));
            u.setTracks(rs.getString("Track_Listing"));
            u.setOther(rs.getString("Other_Specifications"));
            u.setAwards(rs.getString("Awards_if_any"));
            u.setDoc(rs.getString("Sample_Contents_Upload"));
            
           
            list.add(u);  
        }  
    }catch(Exception e){System.out.println(e);}  
    return list;  
}

public static Store getRecordById(int Song_id){  
    Store u=null;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("select * from MyTunes1 where Song_id=?");  
        ps.setInt(1,Song_id);  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            u=new Store();  
            u.setSongId(rs.getInt("Song_id")); 
            u.setTitle(rs.getString("Title"));
            u.setArtist(rs.getString("Artiste"));
            u.setDirector(rs.getString("Music_Director"));
            u.setLang(rs.getString("Language"));
            u.setType(rs.getString("Music_Type"));
            u.setGenre(rs.getString("Genre"));
            u.setAvail(rs.getString("Availibility"));
            u.setFormat(rs.getString("Format"));
            u.setPrice(rs.getDouble("Online_Price"));
            u.setDiscount(rs.getInt("Discount"));
            u.setImg(rs.getString("Cover_Image"));
            u.setTracks(rs.getString("Track_Listing"));
            u.setOther(rs.getString("Other_Specifications"));
            u.setAwards(rs.getString("Awards_if_any"));
            u.setDoc(rs.getString("Sample_Contents_Upload"));
        }  
    }catch(Exception e){System.out.println(e);}  
    return u;  
}
}  

